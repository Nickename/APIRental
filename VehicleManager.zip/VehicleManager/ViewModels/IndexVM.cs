﻿using VehicleManager.Models;

namespace VehicleManager.ViewModels
{
    public class IndexVM
    {
        public List<VehicleCategory> VehicleCategories { get; set; } = new();
    }
}
